using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSUImageCollectSystem.Helpers
{
	using Mono.Options;
	using System.IO;
	public class Args
	{
		OptionSet _opset;
		string[] _args;
		StringBuilder sb = new StringBuilder();

		static Args _defaultArgs = new Args(Environment.GetCommandLineArgs());
		public static Args DefaultArgs
		{
			get { return _defaultArgs; }
		}

		private Args(string[] arg)
		{
			_args = arg;
			IPAddress = "192.168.0.2";
			ShotPerCar = 15;
			Exposure = 0;
			DelayOfCar = 1500;
			Port = 2111;
			DataCheckCount = 5;
			CaptureDelay = 0;
			TriggerDelay = 0;

			InitOpset();
			_opset.Parse(arg);
			sb.Append("Usage: TSUImageCollectSystem [OPTIONS]\n");
			sb.Append("Options:\n");
			_opset.WriteOptionDescriptions(new StringWriter(sb));
			sb.Append("\nExample: TSUImageCollectSystem --ip=192.168.100.2 --shots=15 --delay=1500\n");
		}

		public string AllArgsAndDesc
		{
			get { return sb.ToString(); }
		}

		public string IPAddress
		{
			get; private set;
		}

		public int CaptureDelay
		{ get; private set; }

		public int DataCheckCount
		{ get; private set; }

		public int ShotPerCar
		{ get; private set; }

		public int Exposure
		{ get; private set; }

		public int TriggerDelay
		{ get; private set; }

		public int DelayOfCar
		{ get; private set; }

		public int Port
		{ get; private set; }

		public void InitOpset()
		{
			_opset = new OptionSet()
				{
					{
						"i|ip=","SICK sensor IP Address",
						(val)=>
						{
							IPAddress = val;
						}
					},
					{
						"p|port=","SICK sensor IP Port",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								Port = vl;
							}
						}
					},
					{
						"s|shots=","Image capture per car",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								ShotPerCar = vl;
							}
						}
					},
					{
						"d|delay=","Delay(ms) between Cars (for SICK Sensor)",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								DelayOfCar = vl;
							}
						}
					},
					{
						"b|cdelay=","Delay(ms) before Baumer capture command",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								CaptureDelay = vl;
							}
						}
					},
					{
						"c|check=","Number of data check for car detection",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								DataCheckCount = vl;
							}
						}
					},
					{
						"e|exposure=","Exposure(us) for Baumer Camera",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								Exposure = vl;
							}
						}
					},
					{
						"t|tdelay=","Triggering delay(us) for Baumer Camera",
						(string val)=>
						{
							int vl;
							if(Int32.TryParse(val, out vl))
							{
								TriggerDelay = vl;
							}
						}
					}
				};
		}
	}
}
